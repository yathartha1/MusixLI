#!/usr/bin/env python3

class config:
    def get_key(self):
        return '056655ef3170abe3621cfc1bf361b540'

